# Basic RAG Pipeline

A local Retrieval-Augmented Generation project that loads PDF/Markdown/TXT files, chunks text, creates embeddings with Sentence Transformers, stores vectors in local ChromaDB, retrieves the top 4 chunks, and uses Gemini or Groq to generate an answer.

## Setup (Windows PowerShell)
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

## Add documents
Place 5–10 files (`.pdf`, `.md`, `.txt`) in `data/documents/`. A sample Markdown document is included.

## Configure an LLM
Edit `.env` and add a Gemini key:
```env
LLM_PROVIDER=gemini
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.5-flash
```
Or use Groq:
```env
LLM_PROVIDER=groq
GROQ_API_KEY=your_key_here
GROQ_MODEL=llama-3.3-70b-versatile
```
Never commit `.env` or publish your API key.

## Run
```bash
python ingest.py
python query.py
```
Or ask one question:
```bash
python query.py --question "Why is chunk overlap useful?"
```

The terminal prints retrieved chunks and the generated answer. If an answer is wrong, inspect the retrieved chunks first. The embedding model downloads on first run and runs locally afterward. The hosted LLM needs internet and a valid API key. Scanned PDFs need OCR, which is not included in this starter project.

## Screen recording checklist
1. Show the project folder in VS Code.
2. Show documents in `data/documents/`.
3. Run `python ingest.py`.
4. Run `python query.py`.
5. Ask a question answered by your documents and show retrieved chunks plus answer.
6. Record using Windows Snipping Tool or Xbox Game Bar (`Win + Alt + R`).

## Structure
```text
basic-rag-pipeline/
├── data/documents/sample_notes.md
├── rag/
│   ├── __init__.py
│   ├── config.py
│   ├── document_loader.py
│   ├── chunker.py
│   ├── vector_store.py
│   └── llm.py
├── .env.example
├── .gitignore
├── requirements.txt
├── ingest.py
└── query.py
```
