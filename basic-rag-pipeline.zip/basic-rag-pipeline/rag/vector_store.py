import chromadb
from sentence_transformers import SentenceTransformer
from rag.config import CHROMA_DIR, COLLECTION_NAME, EMBEDDING_MODEL


class LocalVectorStore:
    def __init__(self):
        print(f"[INFO] Loading embedding model: {EMBEDDING_MODEL}")
        self.embedder = SentenceTransformer(EMBEDDING_MODEL)
        self.client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        self.collection = self.client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )

    def reset(self):
        try:
            self.client.delete_collection(COLLECTION_NAME)
        except Exception:
            pass
        self.collection = self.client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )

    def add_chunks(self, chunks: list[dict], batch_size: int = 64):
        for start in range(0, len(chunks), batch_size):
            batch = chunks[start:start + batch_size]
            texts = [item["text"] for item in batch]
            embeddings = self.embedder.encode(
                texts, normalize_embeddings=True, show_progress_bar=False
            ).tolist()
            self.collection.add(
                ids=[item["id"] for item in batch],
                documents=texts,
                embeddings=embeddings,
                metadatas=[{
                    "source": item["source"],
                    "chunk_index": item["chunk_index"],
                } for item in batch],
            )

    def search(self, question: str, top_k: int = 4) -> list[dict]:
        count = self.collection.count()
        if count == 0:
            return []
        embedding = self.embedder.encode(
            [question], normalize_embeddings=True, show_progress_bar=False
        )[0].tolist()
        results = self.collection.query(
            query_embeddings=[embedding],
            n_results=min(top_k, count),
            include=["documents", "metadatas", "distances"],
        )
        found = []
        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        distances = results.get("distances", [[]])[0]
        for doc, meta, distance in zip(docs, metas, distances):
            found.append({
                "text": doc,
                "source": meta.get("source", "unknown"),
                "chunk_index": meta.get("chunk_index", -1),
                "distance": distance,
            })
        return found
