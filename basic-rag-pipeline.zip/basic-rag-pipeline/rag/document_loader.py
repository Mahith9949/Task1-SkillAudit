from pathlib import Path
from pypdf import PdfReader

SUPPORTED_EXTENSIONS = {".pdf", ".md", ".txt"}


def load_documents(directory: Path) -> list[dict]:
    """Load supported files and return text plus source metadata."""
    directory.mkdir(parents=True, exist_ok=True)
    records = []
    paths = sorted(
        p for p in directory.rglob("*")
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS
    )

    for path in paths:
        try:
            if path.suffix.lower() == ".pdf":
                reader = PdfReader(str(path))
                pages = []
                for page_number, page in enumerate(reader.pages, start=1):
                    page_text = (page.extract_text() or "").strip()
                    if page_text:
                        pages.append(f"[Page {page_number}]\n{page_text}")
                text = "\n\n".join(pages)
            else:
                text = path.read_text(encoding="utf-8", errors="replace").strip()

            if text:
                records.append({
                    "text": text,
                    "source": path.relative_to(directory).as_posix(),
                })
            else:
                print(f"[WARN] No extractable text found: {path.name}")
        except Exception as exc:
            print(f"[WARN] Could not read {path.name}: {exc}")
    return records
