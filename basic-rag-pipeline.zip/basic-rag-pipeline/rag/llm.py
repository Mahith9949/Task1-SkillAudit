from rag.config import (
    LLM_PROVIDER, GEMINI_API_KEY, GEMINI_MODEL, GROQ_API_KEY, GROQ_MODEL
)


def generate_answer(question: str, retrieved_chunks: list[dict]) -> str:
    if not retrieved_chunks:
        return "No document chunks were retrieved. Add documents and run `python ingest.py` first."

    context = "\n\n---\n\n".join(
        f"[Source {i}: {chunk['source']} | chunk {chunk['chunk_index']}]\n{chunk['text']}"
        for i, chunk in enumerate(retrieved_chunks, start=1)
    )
    prompt = f"""Answer the question using only the context below.
If the context does not contain enough information, say the answer cannot be found
in the provided documents. Do not invent facts. Cite source labels such as [Source 1].

CONTEXT:
{context}

QUESTION:
{question}

ANSWER:"""

    if LLM_PROVIDER == "gemini":
        if not GEMINI_API_KEY:
            raise RuntimeError(
                "GEMINI_API_KEY is missing in .env. Add a key or configure Groq."
            )
        from google import genai
        client = genai.Client(api_key=GEMINI_API_KEY)
        response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
        return (response.text or "").strip() or "The model returned an empty response."

    if LLM_PROVIDER == "groq":
        if not GROQ_API_KEY:
            raise RuntimeError("GROQ_API_KEY is missing in .env.")
        from groq import Groq
        client = Groq(api_key=GROQ_API_KEY)
        response = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "system", "content": "Use only supplied context and say when evidence is missing."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
        )
        return (response.choices[0].message.content or "").strip()

    raise ValueError("LLM_PROVIDER must be 'gemini' or 'groq' in .env.")
