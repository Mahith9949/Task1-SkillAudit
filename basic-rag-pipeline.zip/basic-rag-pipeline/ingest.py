from rag.config import DOCUMENTS_DIR, CHUNK_SIZE, CHUNK_OVERLAP
from rag.document_loader import load_documents
from rag.chunker import chunk_text
from rag.vector_store import LocalVectorStore


def main():
    print("=" * 64)
    print("BASIC RAG PIPELINE - DOCUMENT INGESTION")
    print("=" * 64)
    documents = load_documents(DOCUMENTS_DIR)
    if not documents:
        print(f"[ERROR] No readable PDF, Markdown, or TXT files in {DOCUMENTS_DIR}")
        print("Add documents to data/documents/ and run this command again.")
        return

    prepared = []
    for document in documents:
        chunks = chunk_text(document["text"], CHUNK_SIZE, CHUNK_OVERLAP)
        for index, chunk in enumerate(chunks):
            prepared.append({
                "id": f"{document['source']}::chunk-{index}",
                "source": document["source"],
                "chunk_index": index,
                "text": chunk,
            })

    if not prepared:
        print("[ERROR] Documents were found, but no text chunks were created.")
        return

    store = LocalVectorStore()
    store.reset()
    store.add_chunks(prepared)
    print(f"Documents loaded : {len(documents)}")
    print(f"Chunks created   : {len(prepared)}")
    print(f"Chunk size       : {CHUNK_SIZE} words")
    print(f"Chunk overlap    : {CHUNK_OVERLAP} words")
    print(f"Stored locally   : {store.collection.count()} chunks")
    print("[SUCCESS] Ingestion complete. Run `python query.py`.")


if __name__ == "__main__":
    main()
