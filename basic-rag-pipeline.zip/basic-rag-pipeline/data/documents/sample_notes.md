# Basic RAG Pipeline Sample Notes

Retrieval-Augmented Generation (RAG) combines information retrieval with text generation. A RAG application searches a collection of documents and supplies relevant passages to a language model when answering a question.

A typical RAG pipeline has these steps:
1. Load documents from sources such as PDF, Markdown, and text files.
2. Split long documents into smaller, overlapping chunks.
3. Convert each chunk into a numerical embedding.
4. Store embeddings and metadata in a vector database.
5. Embed a user's question and retrieve the most similar chunks.
6. Pass the retrieved context and question to a language model.
7. Return an answer and show the sources used.

Chunking is important because very large chunks can contain unrelated information, while tiny chunks can lose context. Overlap helps preserve information across chunk boundaries. The correct chunk size depends on the documents and task.

Sentence Transformers can create embeddings locally. The all-MiniLM-L6-v2 model is a compact general-purpose sentence embedding model. ChromaDB can persist vectors and metadata on the local computer, so a separate vector database server is not required.

Retrieval quality matters. If retrieved chunks do not contain the answer, even a strong language model may produce a wrong or incomplete response. During testing, print retrieved chunks and inspect whether they support the answer.

The language model in this starter project can be Gemini or Groq. Hosted language model APIs require an API key and internet access. API keys must be stored in a local .env file and must not be committed to a public repository.

A RAG system should be transparent about missing evidence. If the retrieved documents do not contain enough information, the model should say that the answer cannot be found in the provided documents instead of inventing facts.

Example question: Why is chunk overlap useful?
Expected answer: Overlap preserves context that might otherwise be split between adjacent chunks.
