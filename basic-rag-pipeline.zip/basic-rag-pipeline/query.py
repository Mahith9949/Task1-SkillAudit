import argparse
from rag.config import TOP_K
from rag.vector_store import LocalVectorStore
from rag.llm import generate_answer


def display_retrieved(chunks: list[dict]):
    print("\n" + "=" * 72)
    print("RETRIEVED CHUNKS (inspect these if an answer is incorrect)")
    print("=" * 72)
    if not chunks:
        print("No chunks retrieved.")
        return
    for index, chunk in enumerate(chunks, start=1):
        print(
            f"\n[{index}] Source: {chunk['source']} | "
            f"Chunk: {chunk['chunk_index']} | Cosine distance: {chunk['distance']:.4f}"
        )
        print("-" * 72)
        print(chunk["text"])


def answer_question(store: LocalVectorStore, question: str):
    chunks = store.search(question, TOP_K)
    display_retrieved(chunks)
    print("\n" + "=" * 72)
    print("GENERATED ANSWER")
    print("=" * 72)
    try:
        print(generate_answer(question, chunks))
    except Exception as exc:
        print(f"[ERROR] Could not generate answer: {exc}")
        print("Check .env, provider/API key, model name, and internet connection.")


def main():
    parser = argparse.ArgumentParser(description="Ask questions over your local documents.")
    parser.add_argument("--question", "-q", help="Ask one question and exit.")
    args = parser.parse_args()

    print("=" * 72)
    print("BASIC RAG PIPELINE - QUESTION ANSWERING")
    print("=" * 72)
    store = LocalVectorStore()
    if store.collection.count() == 0:
        print("[ERROR] Vector database is empty. Run `python ingest.py` first.")
        return

    if args.question:
        answer_question(store, args.question)
        return

    print("Ask about your documents. Type 'exit' or 'quit' to stop.")
    while True:
        try:
            question = input("\nQuestion> ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break
        if question.lower() in {"exit", "quit"}:
            print("Goodbye!")
            break
        if question:
            answer_question(store, question)


if __name__ == "__main__":
    main()
